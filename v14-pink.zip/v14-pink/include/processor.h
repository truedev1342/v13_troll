#ifndef PROCESSOR_H
#define PROCESSOR_H

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "variables.h"
extern struct Command cmdInstructions[]; 

/* Create a node for external references */
struct ExternalRefTb * buildExternalNode(char _stateName[10], int _addrRef);

/* Build the pre-assembler file */
void buildFirstAssemFile(FILE *_resultFile, char* _fileName, struct MacroDefTb **_macroDefTb, FILE ** _inputFile);

/* Clear all the allocated memory */
void emptyMemory(struct SymbolEntry * _bitNodeHead, struct BitElement * _bitCodeTb, struct MacroDefTb  *_macroDefTb, struct ExternalSymbolData * _externalSymbol, struct EntrySymbol * _entrySymbol, struct EntryTbData * _entryTbData, struct ExternalRefTb * _externalTbData);

/* Main function to process assembler code */
void buildCompiler(char** _inputParams,int _paramT, struct ExternalRefTb ** _externalRefTb, struct EntryTbData ** _entryTbData, struct EntrySymbol ** _entrySymbol, struct ExternalSymbolData ** _externalSymbolData, struct MacroDefTb  **_macroDefTb, struct BitElement ** _bitCodeTb,struct SymbolEntry ** _bitNodeHead, struct MacroDefTb  **_macroTbCur, struct MacroElement **_macroElementHead, struct MacroElement **_macroElementCur);

/* Create the symbol table from the assembler file */
struct SymbolEntry * buildSymbolTb(FILE *_inputFile, struct ExternalSymbolData ** _externalSymbolDt, struct EntrySymbol ** _entrySymbolDt);

/* Create a node for macro definitions */
void createNodeDef(char _arrMacroDef[], struct MacroElement ** _macroElementNode);

/* Clear the macro definition table */
void emptyMacroTb(struct MacroDefTb *_macroDefTb);

/* Process an entry symbol and update tables */
void runEntrySymbol(char _symbol[25], struct SymbolEntry **_symbolEntry, struct BitElement **_bitNodeHead, struct BitElement **_bitNodeCur, int **_instruction, int *_addrRef);

/* Build a macro definition table node */
void buildNodeTb(char _arrayDef[], struct MacroDefTb ** _macroDefTbNode);

/* Create an entry symbol node */
void buildNodeEntrySymbol(char _stateName[25], struct EntrySymbol ** _entrySymbolNode);

/* Create an entry table node */
void buildNodeEntryTb(char _stateName[10], int _addrRef, struct EntryTbData ** _entryTbNode);

/* Insert a symbol into the symbol table */
int insertSymbolToTb(char * _symbol, struct SymbolEntry * _handleFile);

/* Create a bit code node */
struct BitElement * buildBitNode(int _addrRef, char _encoded[], char _symbol[]);

/* Create a symbol node */
struct SymbolEntry * buildSymbolNode (char _stateName[], int _numValue);

/* Create an external symbol node */
void buildNodeEnternalSymbol(char _stateName[25], struct ExternalSymbolData ** _externalSymbolNode);

#endif  
