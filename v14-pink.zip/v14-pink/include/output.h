#ifndef OUTPUT_H
#define OUTPUT_H

#include "helper.h"

/* Clear the symbol table */
void emptySymbolTb(struct SymbolEntry * _bitNodeHead);

/* Clear the bit code node table */
void emptyBitNode(struct BitElement * _bitElement);

/* Process an external symbol and update tables */
void runExternalSymbol(char _symbol[25], struct ExternalRefTb **_externalRefTb, struct BitElement **_bitNodeHead, struct BitElement **_bitNodeCur, int **_instruction, int *_addrRef, struct ExternalRefTb **_curExternalRefTb);

/* Handle lines where macros are not present */
void handleMacroPresentNot(char _lineContent[500], int * _activeM, struct MacroDefTb **_macroDefTb, struct MacroDefTb **_macroTbCur);

/* Find the macro definition from the macro table */
struct MacroElement *searchMacroDef(struct MacroDefTb *_macroDefTb, char bufMacro[]);

/* Build an external file from the reference table */
void externalFileBuild(struct ExternalRefTb *_fileBase, char *_baseFileName);

/* Handle lines where macros are present */
void handleMacroPresent(char _lineContent[500], int * _activeM, struct MacroDefTb **_macroTbCur, struct MacroElement **_bitNodeHead, struct MacroElement **_bitNodeCur);

/* Parse macros from the file and update the macro tables */
void decryptAllMacros(FILE *_baseFile, struct MacroDefTb **_macroDefTb, struct MacroDefTb **_macroDefTbCur, struct MacroElement **_bitNodeHead, struct MacroElement **_bitNodeCur);

/* Clean up macro definitions */
void emptyMacroDef(struct MacroElement *_macroElement);

/* Create an object file with binary code */
void buildObjectFile(char * _baseFileName, struct BitElement * _bitElement, int _instruction, int _totalBit);

/* Build binary machine code from assembler file */
struct BitElement * buildBinMachineCode(FILE * _inputFile, struct SymbolEntry ** _symbolEntry, int * _instruction, int *_totalBit, struct ExternalSymbolData ** _externalSymbol, struct EntrySymbol ** _entrySymbol, struct ExternalRefTb ** _externalSymbolOrigin, struct EntryTbData ** _entrySymbolOrigin, int * _idxLine, int *_errStateLine);

/* Create an entry file with table entry data */
void buildEntryFile(char * _baseFileName, struct EntryTbData * _fileHandler);


#endif
