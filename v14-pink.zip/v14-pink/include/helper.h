#ifndef HELPER_H
#define HELPER_H

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "processor.h"

/* Create a new bit code node */
void createBitNode(struct BitElement ** _bitNodeHead, struct BitElement ** _bitNodeCur, int ** _bitCode, int * _addr, char _encoded[], char * _parsed);

/* Insert a constant into the symbol table */
int insertConstant(char _symbol[], struct SymbolEntry * _symbolEntry);

/* Process a constant symbol and update the bit code */
void processConstantSymbol(char _coupon[], struct SymbolEntry ** _symbolEntry, struct BitElement ** _bitNodeHead, struct BitElement ** _bitNodeCur, int ** _instruction, int * _addrRef);

/* Process encoding of utility instructions */
void processEncoding(int _counter, char _encoded[], int _state);

/* Process a register and update the bit code */
void processRegister(char _coupon[], char _nextCoupon[], int * _index, int _token, struct SymbolEntry ** _symbolEntry, struct BitElement ** _bitNodeHead, struct BitElement ** _bitNodeCur, int ** _instruction, int * _addrRef);

/* Process a symbol and update relevant tables */
void processSymbol(char _coupon[], struct SymbolEntry **_symbolEntry, struct BitElement **_bitNodeHead, struct BitElement **_bitNodeCur, int **_instruction, int *_addrRef, struct ExternalRefTb **_externalRefTb, struct EntryTbData **_curEntryTbData, struct EntryTbData **_entryTbData, struct ExternalRefTb **_curExternalRefTb, char _symbol[25], struct ExternalSymbolData **_externalSymbolData, struct EntrySymbol **_entrySymbol);

/* Validate the type of an address */
int validateAddrType(char * _addr);

/* Validate a constant string */
int validateConstant(char * _constant);

/* Check if a symbol is in the symbol table */
int validateSymbolInTb(char * _symbol, struct SymbolEntry * _baseFileName);

/* Validate a command string */
int validateCommand(char * _command);

/* Validate a register string */
int validateRegister(char * _register);

/* Validate an external symbol in the external symbol table */
int validateExternalSymbol(char _symbol[10], struct ExternalSymbolData * _baseFileName);

/* Validate an entry symbol in the entry symbol table */
int validateEntrySymbol(char _symbol[10], struct EntrySymbol * _baseFileName);

/* Clear external symbol data */
void emptyExternalSymbol(struct ExternalSymbolData * _externalSymbol);

/* Clear entry symbol data */
void emptyEntrySymbol(struct EntrySymbol * _entrySymbol);

/* Clear the external symbol table */
void emptyExternalTb(struct ExternalRefTb * _externalSymbolTb);

/* Clear the entry symbol table */
void emptyEntryTb(struct EntryTbData * _entrySymbolTb);

#endif
