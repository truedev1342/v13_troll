#ifndef VARIABLES_H
#define VARIABLES_H

/* Structure for macro definition table */
struct MacroDefTb {
   char macroName[500]; /* Macro name */
   struct MacroDefTb *nextMacro; /* Pointer to the next macro definition */
   struct MacroElement *defPointer; /* Pointer to macro elements */
};

/* Structure for symbol table entry */
struct SymbolEntry {
   char symbolName[10];   /* Symbol name */
   int addrRef;      /* Memory reference for the symbol */
   struct SymbolEntry * next; /* Pointer to the next symbol */
};

/* Structure for macro element */
struct MacroElement {
   char addr[500];          /* Macro definition */
   struct MacroElement *next; /* Pointer to the next macro element */
};

/* Structure for bit code element */
struct BitElement {
   int addrRef;      /* Memory reference */
   char encrypt[8];      /* Binary encoding */
   char symbol[10];     /* Associated symbol */
   struct BitElement * next; /* Pointer to the next bit code element */
};

/* Structure for external reference table */
struct ExternalTb {
   char stateName[10];     /* Statement name */
   int addrRef;     /* Memory reference */
   struct ExternalRefTb * nextPointer; /* Pointer to the next external reference */
};

/* Structure for entry symbol data */
struct EntrySymbol {
   char stateName[25];     /* Statement name */
   struct EntrySymbol * next; /* Pointer to the next entry symbol */
};

/* Structure for table entry data */
struct EntryTbData {
   char stateName[10];     /* Statement name */
   int addrRef;     /* Memory reference */
   struct EntryTbData * next; /* Pointer to the next entry data */
};

/* Command structure with name, operations, and number */
struct Command{
   char * commandName; 
   int operator; 
   int number; 
};

/* Structure for external reference table */
struct ExternalRefTb {
   char stateName[10];     /* Statement name */
   int addrRef;     /* Memory reference */
   struct ExternalRefTb * next; /* Pointer to the next external reference */
};

/* Structure for external symbol data */
struct ExternalSymbolData {
   char stateName[25];     /* Statement name */
   struct ExternalSymbolData * next; /* Pointer to the next external symbol */
};

#endif
