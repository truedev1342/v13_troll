; file error.as

.entry LIST
.extern fn1
MAIN:
MAIN:   add r3, LIST
        jsr fn1
LOOP:   prn #48
	endmacr
        macr m_macr
                cmp r3, #-6
                bne END
        endmacr
        lea STR, r6
        inc r6, #14
        mov *r6, L3
        sub r1 r4
        m_macr
	add r7, *r6
	clr K
	sub L3,
	absent_macro
.entry MAIN
        jmp LOOP
END:    stop
STR:    .string "abcd"
LIST:   .data 6 -9
        .data -100
K:      .data 31
