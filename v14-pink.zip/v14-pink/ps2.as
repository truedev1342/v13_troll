; file ps2.as

.entry START
.extern func1
START:  mov #10, r2
        add r2, r3
        jsr func1
CHECK:  prn r3
        macr arith_macr
                cmp r3, #5
                bne SKIP
        endmacr
        dec r3
        clr r1
        arith_macr
        sub r3, r1
        bne CHECK
SKIP:   prn r1
        jmp END
END:    stop
.extern r3
