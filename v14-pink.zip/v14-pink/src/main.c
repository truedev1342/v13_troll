#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "processor.h"

int main(int number_of_agrc, char** inputArgs )
{  
    int k;
    /* Process each input argument */
    for(k=1;k<number_of_agrc;k++){
        struct ExternalRefTb * externTableState=NULL;
        struct EntryTbData * entryTableState=NULL;
        struct EntrySymbol * entSymbol=NULL;
        struct ExternalSymbolData * extSymbol=NULL;
        struct MacroDefTb  *MacroDefinitionTable_ptr = NULL;
        struct BitElement * pbitCodeTable;
        struct SymbolEntry * bitCodeNodeHead;
        struct MacroDefTb  *macroTableCursor_curr = NULL;
        struct MacroElement *bitCodeNodeHead_ptr = NULL;
        struct MacroElement *curr_ptr = NULL;
        /* Call makeAssembler to process the file */
        buildCompiler(inputArgs,k, &externTableState, &entryTableState, &entSymbol, &extSymbol, &MacroDefinitionTable_ptr, &pbitCodeTable, &bitCodeNodeHead, &macroTableCursor_curr, &bitCodeNodeHead_ptr, &curr_ptr);
    }
    return 0;
}
