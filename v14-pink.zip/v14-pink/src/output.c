#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "output.h"

/* Build an object file from bit code data */
void buildObjectFile(char * _baseFileName, struct BitElement * _bitElement, int _instruction, int _totalBit) {
    FILE *outputFile;
    char fullFileName[25] = "test_it";
    if (_baseFileName == NULL || _bitElement == NULL) {
        return;
    }

    sprintf(fullFileName, "%s.ob", _baseFileName); /* Create file name */
    
    outputFile = fopen(fullFileName, "w"); /* Open file for writing */
    
    fprintf(outputFile, "%02d %02d\n", _instruction, _totalBit); /* Write header */
    
    while (_bitElement != NULL) {
        fprintf(outputFile, "%04d %s\n", _bitElement->addrRef, _bitElement->encrypt); /* Write bit code */
        _bitElement = _bitElement->next;
    }
    
    fclose(outputFile); /* Close file */
    return;
}


/* Clear the symbol table */
void emptySymbolTb(struct SymbolEntry *_bitNodeHead) {
    if (_bitNodeHead == NULL) return;
    if (_bitNodeHead->next != NULL) {
        emptySymbolTb(_bitNodeHead->next);
    }
    free(_bitNodeHead);    
}

/* Clear the bit code nodes */
void emptyBitNode(struct BitElement *_bitElement) {
    if (_bitElement == NULL) return;
    if (_bitElement->next != NULL) {
        emptyBitNode(_bitElement->next);
    }
    free(_bitElement);
}

/* Find the macro definition in the macro table */
struct MacroElement *searchMacroDef(struct MacroDefTb *_macroDefTb, char bufMacro[])
{
    while (_macroDefTb)
    {
        if (strcmp(bufMacro, _macroDefTb->macroName) == 0)
        {
            return _macroDefTb->defPointer;  /* Return macro definition if found */
        }
        _macroDefTb = _macroDefTb->nextMacro;  /* Move to next macro table entry */
    }
    return NULL;  /* Return NULL if not found */
}


/* Recursively free memory for macro definitions */
void emptyMacroDef(struct MacroElement *_macroElement)
{
    if (_macroElement == NULL)
        return;
    if (_macroElement->next != NULL)
    {
        emptyMacroDef(_macroElement->next);  /* Free next element recursively */
    }
    free(_macroElement);  /* Free current element */
}

/* Handle macro definitions found in the content line */
void handleMacroPresent(char _lineContent[500], int * _activeM, struct MacroDefTb **_macroTbCur, struct MacroElement **_bitNodeHead, struct MacroElement **_bitNodeCur){
    char vectorMacroDef[500];
    char *state2;
    strcpy(vectorMacroDef, _lineContent);  /* Copy content line to a new array */
    state2 = strtok(_lineContent, " \t\n");  /* Tokenize content line */

    while (state2 != NULL){
        if (strcmp(state2, "endmacr") == 0)
        {
            *_activeM = 0;  /* End macro processing */
            (*_macroTbCur)->defPointer = *_bitNodeHead;  /* Set macro definition pointer */
            *_bitNodeHead = NULL;  /* Clear bit code list head */
            *_bitNodeCur = NULL;  /* Clear current pointer */
            break;
        }
        state2 = strtok(NULL, " \t\n");  /* Get next token */
    }

    if (*_activeM == 1){
        if (*_bitNodeHead != NULL){
            createNodeDef(vectorMacroDef, &((*_bitNodeCur)->next));  /* Add new node to the end of the list */
            *_bitNodeCur = (*_bitNodeCur)->next;  /* Update current pointer */
        }
        else{
            createNodeDef(vectorMacroDef, _bitNodeHead);  /* Create new node if list is empty */
            *_bitNodeCur = *_bitNodeHead;  /* Set current pointer to the new node */
        }
    }
}

/* Handle lines when macros are not present */
void handleMacroPresentNot(char _lineContent[500], int * _activeM, struct MacroDefTb **_macroDefTb, struct MacroDefTb **_macroTbCur){
    char *decrypt = strtok(_lineContent, " \t\n");  /* Tokenize content line */

    while (decrypt != NULL){
        if (strcmp(decrypt, "macr") == 0){
            char macroName[500];
            *_activeM = 1;  /* Activate macro processing */
            decrypt = strtok(NULL, " \t\n");  /* Get macro name */
            strcpy(macroName, decrypt);  /* Copy macro name */

            if (*_macroDefTb != NULL){
                buildNodeTb(macroName, &((*_macroTbCur)->nextMacro));  /* Add new macro to the table */
                *_macroTbCur = (*_macroTbCur)->nextMacro;  /* Update current cursor */
            }
            else{
                buildNodeTb(macroName, _macroDefTb);  /* Initialize table if empty */
                *_macroTbCur = *_macroDefTb;  /* Set current cursor */
            }
            break;
        }

        decrypt = strtok(NULL, " \t\n");  /* Get next token */
    }
}

/* Parse macro definitions from a file */
void decryptAllMacros(FILE *_baseFile, struct MacroDefTb **_macroDefTb, struct MacroDefTb **_macroDefTbCur, struct MacroElement **_bitNodeHead, struct MacroElement **_bitNodeCur)
{
    char lineContent[500];
    int activeM = 0;  /* Initialize macro active flag */

    while (fgets(lineContent, sizeof(lineContent), _baseFile))
    {
        if (activeM == 0)
        {
            handleMacroPresentNot(lineContent, &activeM, _macroDefTb, _macroDefTbCur);  /* Handle non-macro lines */   
        }
        else if (activeM == 1)
        {
            handleMacroPresent(lineContent, &activeM, _macroDefTbCur, _bitNodeHead, _bitNodeCur);  /* Process macro content */
        }
    }
}

/* Build an external file from the external reference table */
void externalFileBuild(struct ExternalRefTb *_fileBase, char *_baseFileName)
{
    FILE *externalSymbolFile;
    char fileNameExternal[25];
    sprintf(fileNameExternal, "%s.ext", _baseFileName);  /* Create external file name */
    externalSymbolFile = fopen(fileNameExternal, "w");  /* Open file for writing */

    if (!externalSymbolFile) {
        perror("Error opening file");  /* Handle file open error */
        return;
    }

    while (_fileBase != NULL)
    {
        fprintf(externalSymbolFile, "%s %04d\n", _fileBase->stateName, _fileBase->addrRef);  /* Write to external file */
        _fileBase = _fileBase->next;  /* Move to next table entry */
    }

    fclose(externalSymbolFile);  /* Close the file */
}


struct BitElement * buildBinMachineCode(FILE * _inputFile, struct SymbolEntry ** _symbolEntry, int * _instruction, int *_totalBit, struct ExternalSymbolData ** _externalSymbol, struct EntrySymbol ** _entrySymbol, struct ExternalRefTb ** _externalSymbolOrigin, struct EntryTbData ** _entrySymbolOrigin, int * _idxLine, int *_errStateLine) {
    struct ExternalRefTb * curExternalTbPtr = NULL;
    struct ExternalRefTb * externalTbState = NULL;
    struct EntryTbData * curEntryTbPointer = NULL;
    struct EntryTbData * entryTbState = NULL;
    struct BitElement * bitNodeCur = NULL;
    struct BitElement * bitNodeHead = NULL;
    int token = 0;
    int addrRef;
    char lineContent[500];
    addrRef = 100;
    (*_idxLine) = 0;
    
    while (fgets(lineContent, sizeof(lineContent), _inputFile)) {
        int idx = 0;
        char * parsed;
        char * coupon[5];
        token = 0;
        parsed = strtok(lineContent, " \t");
        (*_idxLine)++;
        
        while (parsed != NULL && parsed[0] != '\n' && parsed[0] != '\0') {
            coupon[token++] = parsed;
            parsed = strtok(NULL, " \t\n");
        }
        
        for (idx = 0; idx < token; idx++) {
            if (idx == 0) {
                int sz = 0;
                
                if (strchr(coupon[idx], ';') != 0 || strcmp(coupon[idx], ".extern") == 0) break;
                else if (strcmp(coupon[idx],".string")==0){
                    idx++;
                    while (idx < token) {
                        char contentStr[100];
                        int sz = 0;
                        int t;
                        while (coupon[idx][sz] != '\0') {
                            sz++;
                        }
                        t = 1;
                        for (t = 1; t < sz - 1; t++) {
                            contentStr[t - 1] = coupon[idx][t];
                        }
                        contentStr[sz - 2] = '\0';
                        for (t = 0; t < sz - 1; t++) {
                            int stateBinaryCode;
                            char arr_encode[6];
                            int _cnt_;
                            stateBinaryCode = contentStr[t];
                            arr_encode[5] = '\0';
                            _cnt_ = 4;
                            while (_cnt_ >= 0) {
                                int _res_;
                                _res_ = stateBinaryCode & 7;
                                arr_encode[_cnt_] =(_res_ + '0');
                                stateBinaryCode = stateBinaryCode >> 3;
                                _cnt_--;
                            }
                            if (bitNodeHead == NULL) {
                                char temp[2];
                                temp[0] = contentStr[t];
                                temp[1] = '\0';
                                (*_totalBit)++;
                                bitNodeHead = buildBitNode(addrRef++, arr_encode, temp);
                                bitNodeCur = bitNodeHead;
                            }
                            else {
                                char temp[2];
                                temp[0] = contentStr[t];
                                temp[1] = '\0';
                                (*_totalBit)++;
                                bitNodeCur->next = buildBitNode(addrRef++, arr_encode, temp);
                                bitNodeCur = bitNodeCur->next;
                            }
                        }
                        idx++;
                    }
                    break;
                }
                else if (strcmp(coupon[idx],".data")==0){
                    int codeState;
                    idx++;
                    while (idx < token) {
                        int sz = 0;
                        char symbol[25];
                        int t = 0;
                        char encoded[6];
                        int cnt;
                        while (coupon[idx][sz] != '\0' && coupon[idx][sz] != ',') {
                            sz++;
                        }
                        
                        for (t = 0; t < sz; t++) {
                            symbol[t] = coupon[idx][t];
                        }
                        symbol[sz] = '\0';
                        if (symbol[0] == '-') {
                            int num = 0;
                            int trade;
                            int t;
                            trade = 1;
                            t = sz - 1;
                            for (t = sz - 1; t > 0; t--) {
                                num = num + (coupon[idx][t] - '0') * trade;
                                trade *= 10;
                            }
                            num = ~num + 1;
                            codeState = num;
                        }
                        else if (symbol[0] >= 48 && symbol[0] <= 57) {
                            int trade;
                            int num = 0;
                            int t;
                            t = sz - 1;
                            trade = 1;
                            for (t = sz - 1; t >= 0; t--) {
                                num = num + ((symbol[t] - '0') * trade);
                                trade *= 10;
                            }
                            codeState = num;
                        }
                        else {
                            codeState = insertConstant(symbol, *_symbolEntry);
                        }
                        encoded[5] = '\0';
                        cnt = 4;
                        while (cnt >= 0) {
                            int _res_;
                            _res_ = codeState & 7;
                            encoded[cnt] = (_res_ + '0');
                            codeState = codeState >> 3;
                            cnt--;
                        }
                        if (bitNodeHead == NULL) {
                            (*_totalBit)++;
                            bitNodeHead = buildBitNode(addrRef++, encoded, symbol);
                            bitNodeCur = bitNodeHead;
                        }
                        else {
                            (*_totalBit)++;
                            bitNodeCur->next = buildBitNode(addrRef++, encoded, symbol);
                            bitNodeCur = bitNodeCur->next;
                        }
                        idx++;
                    }
                    break;   
                }
                else if (strcmp(coupon[idx], ".entry") == 0){
                    int cntEntry;
                    cntEntry = insertSymbolToTb(coupon[idx+1], *_symbolEntry);
                    if (entryTbState == NULL) {
                        buildNodeEntryTb(coupon[idx+1], cntEntry, &entryTbState);
                        curEntryTbPointer = entryTbState;
                    }
                    else {
                        buildNodeEntryTb(coupon[idx+1], cntEntry, &(curEntryTbPointer->next));
                        curEntryTbPointer = curEntryTbPointer->next;
                    }
                    break;
                }
                
                while (coupon[idx][sz] != '\0') {
                    sz++;
                }

                if (coupon[idx][sz - 1] != ':') {
                    int idxState = 0;
                    
                    while (strcmp(cmdInstructions[idxState].commandName, coupon[idx])) {
                        idxState++;
                        if (idxState > 16) {
                            printf("Error: at contentLine %d command operator not identified\n", (*_idxLine));
                            (*_errStateLine) = 1;
                            break;
                        }
                    }
                    
                    if (validateCommand(coupon[idx]) && ((token - idx - 1) != cmdInstructions[idxState].operator)) {
                        printf("Error: at contentLine %d number of arguments are wrong\n", (*_idxLine));
                        (*_errStateLine) = 1;
                    }
                    
                    if (cmdInstructions[idxState].operator == 0) {
                        int cnt;
                        char encoded[6];
                        int codeState;
                        int operator;
                        operator = idxState;
                        codeState = (operator << 11) | (4);
                        encoded[5] = '\0';
                        cnt = 4;
                        
                        processEncoding(cnt, encoded, codeState);
                        
                        createBitNode(&bitNodeHead, &bitNodeCur, &_instruction, &addrRef, encoded, coupon[idx]);
                    }
                    else if (cmdInstructions[idxState].operator == 1) {
                        int cnt;
                        char encoded[6];
                        int codeState;
                        int addrMTar;
                        int operator;
                        operator = idxState;
                        addrMTar = validateAddrType(coupon[idx + 1]);
                        codeState = (operator << 11) | (addrMTar << 3) | (4);
                        encoded[5] = '\0';
                        cnt = 4;
                        
                        processEncoding(cnt, encoded, codeState);
                        
                        createBitNode(&bitNodeHead, &bitNodeCur, &_instruction, &addrRef, encoded, coupon[idx]);
                    }
                    else if (cmdInstructions[idxState].operator == 2) {
                        int cnt;
                        char encoded[6];
                        int codeState;
                        int addrMSrc;
                        int addrMTar;
                        int operator;
                        operator = idxState;
                        addrMTar = validateAddrType(coupon[idx + 2]);
                        addrMSrc = validateAddrType(coupon[idx + 1]);
                        codeState = (operator << 11) | (addrMTar << 3) | (addrMSrc << 7) | (4);
                        encoded[5] = '\0';
                        cnt = 4;
            
                        processEncoding(cnt, encoded, codeState);
                        
                        createBitNode(&bitNodeHead, &bitNodeCur, &_instruction, &addrRef, encoded, coupon[idx]);
                    }
                }
               
            }
            else {
                int y = 0;
                char symbol[25];
                int sz = 0;
                int rltCmd = 0;
                rltCmd = validateCommand(coupon[idx]);
                
                while (coupon[idx][sz] != ',' && coupon[idx][sz] != '\0') {
                    sz++;
                }
                
                for (y = 0; y < sz; y++) {
                    symbol[y] = coupon[idx][y];
                }
                symbol[sz] = '\0';
                
                if (rltCmd) {
                    if ((token - idx - 1) != cmdInstructions[rltCmd - 1].operator) {
                        printf("Error: at contentLine %d number of arguments are wrong\n", (*_idxLine));
                        (*_errStateLine) = 1;
                    }
                    if (cmdInstructions[rltCmd - 1].operator == 2) {
                        int cnt;
                        char encoded[6];
                        int codeState;
                        int addrMSrc;
                        int addrMTar;
                        int operator;
                        operator = rltCmd - 1;
                        addrMTar = validateAddrType(coupon[idx + 2]);
                        addrMSrc = validateAddrType(coupon[idx + 1]);
                        codeState = (operator << 11) | (addrMTar << 3) | (addrMSrc << 7) | (4);
                        encoded[5] = '\0';
                        cnt = 4;
                        
                        processEncoding(cnt, encoded, codeState);
                        
                        createBitNode(&bitNodeHead, &bitNodeCur, &_instruction, &addrRef, encoded, coupon[idx]);
                    }
                    else if (cmdInstructions[rltCmd - 1].operator == 0) {
                        int operator;
                        int codeState;
                        char encoded[6];
                        int cnt;
                        operator = rltCmd - 1;
                        codeState = operator << 11 | (4);
                        encoded[5] = '\0';
                        cnt = 4;
                        
                        processEncoding(cnt, encoded, codeState);
                        
                        createBitNode(&bitNodeHead, &bitNodeCur, &_instruction, &addrRef, encoded, coupon[idx]);
                    }
                    else if (cmdInstructions[rltCmd - 1].operator == 1) {
                        int cnt;
                        char encoded[6];
                        int codeState;
                        int addrMTar;
                        int operator;
                        operator = rltCmd - 1;
                        addrMTar = validateAddrType(coupon[idx + 1]);
                        codeState = (operator << 11) | (addrMTar << 3) | (4);
                        encoded[5] = '\0';
                        cnt = 4;
                        
                        processEncoding(cnt, encoded, codeState);
                        
                        createBitNode(&bitNodeHead, &bitNodeCur, &_instruction, &addrRef, encoded, coupon[idx]);
                    }
                }
                else if (strstr(coupon[idx], ".string") != NULL) {
                    idx++;
                    while (idx < token) {
                        char strContent[100];
                        int sz = 0;
                        int t;
                        while (coupon[idx][sz] != '\0') {
                            sz++;
                        }
                        t = 1;
                        for (t = 1; t < sz - 1; t++) {
                            strContent[t - 1] = coupon[idx][t];
                        }
                        strContent[sz - 2] = '\0';
                        for (t = 0; t < sz - 1; t++) {
                            int codeState;
                            char encoded[6];
                            int cnt;
                            codeState = strContent[t];
                            encoded[5] = '\0';
                            cnt = 4;
                            while (cnt >= 0) {
                                int rlt;
                                rlt = codeState & 7;
                                encoded[cnt] =(rlt + '0');
                                codeState = codeState >> 3;
                                cnt--;
                            }
                            if (bitNodeHead != NULL) {
                                char temp[2];
                                temp[0] = strContent[t];
                                temp[1] = '\0';
                                (*_totalBit)++;
                                bitNodeCur->next = buildBitNode(addrRef++, encoded, temp);
                                bitNodeCur = bitNodeCur->next;
                            }
                            else {
                                char temp[2];
                                temp[0] = strContent[t];
                                temp[1] = '\0';
                                (*_totalBit)++;
                                bitNodeHead = buildBitNode(addrRef++, encoded, temp);
                                bitNodeCur = bitNodeHead;
                            }
                        }
                        idx++;
                    }
                }

                else if (strstr(coupon[idx], ".data") != NULL) {
                    int stateBinaryCode;
                    idx++;
                    while (idx < token) {
                        int sz = 0;
                        char symbol[25];
                        int t = 0;
                        char encoded[6];
                        int cnt;
                        while (coupon[idx][sz] != '\0' && coupon[idx][sz] != ',') {
                            sz++;
                        }
                        for (t = 0; t < sz; t++) {
                            symbol[t] = coupon[idx][t];
                        }
                        symbol[sz] = '\0';
                        if (symbol[0] == '-') {
                            int num = 0;
                            int trade;
                            int t;
                            trade = 1;
                            t = sz - 1;
                            for (t = sz - 1; t > 0; t--) {
                                num = num + (coupon[idx][t] - '0') * trade;
                                trade *= 10;
                            }
                            num = ~num + 1;
                            stateBinaryCode = num;
                        }
                        else if (symbol[0] >= 48 && symbol[0] <= 57) {
                            int trade;
                            int num = 0;
                            int t;
                            t = sz - 1;
                            trade = 1;
                            for (t = sz - 1; t >= 0; t--) {
                                num = num + ((symbol[t] - '0') * trade);
                                trade *= 10;
                            }
                            stateBinaryCode = num;
                        }
                        else {
                            stateBinaryCode = insertConstant(symbol, *_symbolEntry);
                        }
                        encoded[5] = '\0';
                        cnt = 4;
                        while (cnt >= 0) {
                            int rlt;
                            rlt = stateBinaryCode & 7;
                            encoded[cnt] = (rlt + '0');
                            stateBinaryCode = stateBinaryCode >> 3;
                            cnt--;
                        }
                        if (bitNodeHead == NULL) {
                            (*_totalBit)++;
                            bitNodeHead = buildBitNode(addrRef++, encoded, symbol);
                            bitNodeCur = bitNodeHead;
                        }
                        else {
                            (*_totalBit)++;
                            bitNodeCur->next = buildBitNode(addrRef++, encoded, symbol);
                            bitNodeCur = bitNodeCur->next;
                        }
                        idx++;
                    }
                }
                else if (validateEntrySymbol(symbol, *_entrySymbol)) {
                    runEntrySymbol(symbol,_symbolEntry, &bitNodeHead, &bitNodeCur, &_instruction , &addrRef);
                }
                else if (validateSymbolInTb(symbol, *_symbolEntry)) {
                    processSymbol(coupon[idx], _symbolEntry, &bitNodeHead, &bitNodeCur, &_instruction, &addrRef, &externalTbState, &curEntryTbPointer, &entryTbState, &curExternalTbPtr, symbol ,_externalSymbol, _entrySymbol);
                }
                else if (validateRegister(coupon[idx])) {
                    processRegister(coupon[idx],coupon[idx+1],&idx,token, _symbolEntry, &bitNodeHead,&bitNodeCur,&_instruction,&addrRef);
                }
                else if (validateExternalSymbol(symbol, *_externalSymbol)) {
                    runExternalSymbol(symbol,&externalTbState, &bitNodeHead, &bitNodeCur, &_instruction, &addrRef,&curExternalTbPtr);
                }
                else if (validateConstant(coupon[idx])) {
                    processConstantSymbol(coupon[idx],_symbolEntry,&bitNodeHead,&bitNodeCur,&_instruction,&addrRef);
                }
                else if (!((symbol[0] >= '0' && symbol[0] <= '9') || (symbol[0] == '-'))) {
                    printf("%s",symbol);
                    printf("Error: at contentLine %d invalid instruction_name\n", (*_idxLine));
                    (*_errStateLine) = 1;
                }
            }
        }
    }
    (*_externalSymbolOrigin) = externalTbState;
    (*_entrySymbolOrigin) = entryTbState;
    return bitNodeHead;
}

/* Process an external symbol and update the external table */
void runExternalSymbol(char _symbol[25], struct ExternalRefTb **_externalRefTb, struct BitElement **_bitNodeHead, struct BitElement **_bitNodeCur, int **_instruction, int *_addrRef, struct ExternalRefTb **_curExternalRefTb) {
    char encoded[6];
    int cnt;
    int codeState;
    cnt = 4;
    codeState = 1;
    processEncoding(cnt, encoded, codeState);
    
    /* Create bit code node */
    createBitNode(_bitNodeHead, _bitNodeCur, _instruction, _addrRef, encoded, _symbol);

    /* Add symbol to external table */
    if (*_externalRefTb == NULL) {
        *_externalRefTb = buildExternalNode(_symbol, *_addrRef - 1);
        *_curExternalRefTb = *_externalRefTb;
    } else {
        (*_curExternalRefTb)->next = buildExternalNode(_symbol, *_addrRef - 1);
        (*_curExternalRefTb) = (*_curExternalRefTb)->next;
    }
}

/* Build an entry file from entry table data */
void buildEntryFile(char * _baseFileName, struct EntryTbData * _fileHandler) {
    FILE *ent_file_ptr;
    char ent_file_name[25];

    sprintf(ent_file_name, "%s.ent", _baseFileName); /* Create file name */
    
    ent_file_ptr = fopen(ent_file_name, "w"); /* Open file for writing */
    
    while (_fileHandler != NULL) {
        fprintf(ent_file_ptr, "%s %04d\n", _fileHandler->stateName, _fileHandler->addrRef); /* Write entry data */
        _fileHandler = _fileHandler->next;
    }
    
    fclose(ent_file_ptr); /* Close file */
}

/* Encode stateBinaryCode into binary format */
void processEncoding(int _counter, char _encoded[], int _state) {
    _encoded[_counter + 1] = '\0';
    while (_counter >= 0) {
        int _res_;
        _res_ = _state & 7; /* Extract last 3 bits */
        _encoded[_counter] = (_res_ + '0'); /* Convert to character */
        _state = _state >> 3; /* Shift right */
        _counter--;
    }
}