#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "output.h"

struct Command cmdInstructions[] = {
    {"mov", 2, 1}, 
    {"cmp", 2, 2}, 
    {"add", 2, 3}, 
    {"sub", 2, 4}, 
    {"lea", 2, 5}, 
    {"clr", 1, 6}, 
    {"not", 1, 7}, 
    {"inc", 1, 8}, 
    {"dec", 1, 9},
    {"jmp", 1, 10}, 
    {"bne", 1, 11}, 
    {"red", 1, 12}, 
    {"prn", 1, 13}, 
    {"jsr", 1, 14}, 
    {"rts", 0, 15}, 
    {"stop", 0, 16}
};

int idxLine=0; /* Index for line tracking */
int errStateLine=0; /* Status for line error detection */

struct SymbolEntry * buildSymbolNode (char _stateName[], int _numValue){
    /* Allocate memory for a new symbol node */
    struct SymbolEntry * elementSymbol=(struct SymbolEntry *)malloc(sizeof(struct SymbolEntry));
    int t;
    /* Copy symbol name into the new node */
    for(t=0;t<10;t++){
        elementSymbol->symbolName[t]=_stateName[t];
    }
    elementSymbol->addrRef=_numValue; /* Set memory reference */
    elementSymbol->next=NULL; /* Initialize next pointer to NULL */
    return elementSymbol;
}

void createNodeDef(char _arrMacroDef[], struct MacroElement ** _macroElementNode) {
    /* Allocate memory for a new macro element node */
    struct MacroElement *elementMacro = (struct MacroElement *)malloc(sizeof(struct MacroElement));
    int t;
    /* Copy the macro definition into the node */
    for (t = 0; t < 500; t++) {
        elementMacro->addr[t] = _arrMacroDef[t];
    }
    /* Initialize the next pointer */
    elementMacro->next = NULL;
    /* Set the node to point to the newly created element */
    *_macroElementNode = elementMacro;
}

void buildNodeEntrySymbol(char _stateName[25], struct EntrySymbol ** _entrySymbolNode) {
    /* Allocate memory for a new entry symbol node */
    struct EntrySymbol * elementEntry = (struct EntrySymbol *)malloc(sizeof(struct EntrySymbol));
    int t;
    /* Copy the statement name into the node */
    for(t = 0; t < 25; t++) {
        elementEntry->stateName[t] = _stateName[t];
    }
    /* Set the next pointer */
    elementEntry->next = NULL;
    /* Set the node to point to the newly created element */
    *_entrySymbolNode = elementEntry;
}


void emptyMemory(struct SymbolEntry * _bitNodeHead, struct BitElement * _bitCodeTb, struct MacroDefTb  *_macroDefTb, struct ExternalSymbolData * _externalSymbol, struct EntrySymbol * _entrySymbol, struct EntryTbData * _entryTbData, struct ExternalRefTb * _externalTbData){
    /* Clear all allocated memory by calling respective clear functions */
    emptyExternalTb(_externalTbData);
    emptyEntryTb(_entryTbData);
    emptyEntrySymbol(_entrySymbol);
    emptyExternalSymbol(_externalSymbol);
    emptyMacroTb(_macroDefTb);
    emptyBitNode(_bitCodeTb);
    emptySymbolTb(_bitNodeHead);
}

void buildNodeEnternalSymbol(char _stateName[25], struct ExternalSymbolData ** _externalSymbolNode) {
    /* Allocate memory for a new external symbol node */
    struct ExternalSymbolData * elementEnternal = (struct ExternalSymbolData *)malloc(sizeof(struct ExternalSymbolData));
    int t;
    /* Copy the statement name into the node */
    for(t = 0; t < 25; t++) {
        elementEnternal->stateName[t] = _stateName[t];
    }
    /* Set the next pointer */
    elementEnternal->next = NULL;
    /* Set the node to point to the newly created element */
    *_externalSymbolNode = elementEnternal;
}

void buildCompiler(char** _inputParams,int _paramT, struct ExternalRefTb ** _externalRefTb, struct EntryTbData ** _entryTbData, struct EntrySymbol ** _entrySymbol, struct ExternalSymbolData ** _externalSymbolData, struct MacroDefTb  **_macroDefTb, struct BitElement ** _bitCodeTb,struct SymbolEntry ** _bitNodeHead, struct MacroDefTb  **_macroTbCur, struct MacroElement **_macroElementHead, struct MacroElement **_macroElementCur){
    int instruction=0;
    int totBit=0;
    FILE *inputFile;
    FILE *outputFile;
    char outputFileName[25];
    char baseFileName[25];
    idxLine=0; /* Reset line index */
    /* Create file names for input and output files */
    sprintf(baseFileName, "%s.as", _inputParams[_paramT]);
    sprintf(outputFileName, "%s.am", _inputParams[_paramT]);
    /* Open input file for reading */
    outputFile = fopen(baseFileName, "r");
    if(outputFile==NULL){
        printf("Error in opening %s\n",baseFileName);
    }
    if (outputFile != NULL)
    {
        /* Parse macros from the input file */
        decryptAllMacros(outputFile, _macroDefTb, _macroTbCur, _macroElementHead, _macroElementCur);
    }
    rewind(outputFile);
       
    /* Open output file for writing */
    inputFile=fopen(outputFileName,"w+");
    if(inputFile==NULL){
        printf("Error in opening %s\n",outputFileName);
    }
    /* Build the pre-assembler file */
    buildFirstAssemFile(outputFile,_inputParams[_paramT],_macroDefTb,&inputFile);
    rewind(inputFile);

    /* Build the symbol table from the assembler file */
    *_bitNodeHead=buildSymbolTb(inputFile,_externalSymbolData,_entrySymbol);

    if(!errStateLine){
        /* Build the binary machine code */
        *_bitCodeTb=buildBinMachineCode(inputFile,_bitNodeHead,&instruction,&totBit,_externalSymbolData,_entrySymbol,_externalRefTb,_entryTbData,&idxLine,&errStateLine);
    }
    fclose(inputFile);
    if(!errStateLine){
        /* Build the object file, entry file, and external file */
        buildObjectFile(_inputParams[_paramT],*_bitCodeTb,instruction,totBit);
        buildEntryFile(_inputParams[_paramT],*_entryTbData);
        externalFileBuild(*_externalRefTb,_inputParams[_paramT]);
    }
    /* Free all allocated memory */
    emptyMemory(*_bitNodeHead, *_bitCodeTb, *_macroDefTb, *_externalSymbolData, *_entrySymbol, *_entryTbData, *_externalRefTb);
    fclose(outputFile);
}

int insertSymbolToTb(char * _symbol, struct SymbolEntry * _handleFile){
    /* Search for the symbol in the symbol table */
    while(_handleFile!=NULL){
        if(strstr(_symbol,_handleFile->symbolName)!=NULL){
            return _handleFile->addrRef; /* Return memory reference if found */
        }
        _handleFile=_handleFile->next;
    }
    return 0; /* Return 0 if symbol not found */
}

struct BitElement * buildBitNode(int _addrRef, char _encoded[], char _symbol[]){
    /* Allocate memory for a new bit code node */
    int t;
    struct BitElement * elementBit=(struct BitElement *)malloc(sizeof(struct BitElement));
    elementBit->addrRef=_addrRef; /* Set memory reference */
    /* Copy encoding into the new node */
    for(t=0;t<8;t++){
        elementBit->encrypt[t]=_encoded[t];
    }
    elementBit->encrypt[7]='\0'; /* Null-terminate encoding */
    /* Copy symbol into the new node */
    for(t=0;t<10;t++){
        elementBit->symbol[t]=_symbol[t];
    }
    elementBit->next=NULL; /* Initialize next pointer to NULL */
    return elementBit;
}


/* Recursively clear macro definition table */
void emptyMacroTb(struct MacroDefTb *_macroDefTb)
{
    if (_macroDefTb == NULL)
        return;
    if (_macroDefTb->nextMacro != NULL)
    {
        emptyMacroTb(_macroDefTb->nextMacro);  /* Clear next macro table element recursively */
    }
    if (_macroDefTb->defPointer != NULL)
    {
        emptyMacroDef(_macroDefTb->defPointer);  /* Clean up macro definitions */
    }
    free(_macroDefTb);  /* Free macro table element */
}

/* Process an entry symbol and add it to the bit code */
void runEntrySymbol(char _symbol[25], struct SymbolEntry **_symbolEntry, struct BitElement **_bitNodeHead, struct BitElement **_bitNodeCur, int **_instruction, int *_addrRef) {
    int cntEntry;
    int codeState;
    char encoded[6];
    int cnt;

    /* Insert symbol and compute state binary code */
    cntEntry = insertSymbolToTb(_symbol, *_symbolEntry);
    codeState = (cntEntry << 3) | 2;
    cnt = 4;
    processEncoding(cnt, encoded, codeState);
    
    /* Create bit code node */
    createBitNode(_bitNodeHead, _bitNodeCur, _instruction, _addrRef, encoded, _symbol);
}

struct SymbolEntry * buildSymbolTb(FILE *_inputFile, struct ExternalSymbolData ** _externalSymbolDt, struct EntrySymbol ** _entrySymbolDt){
    char lineContent[500];
    int cntIndex=99;  /* Initialize counter for memory address */
    struct SymbolEntry * symbolEntryHead=NULL;  /* Head of the symbol table */
    struct SymbolEntry * symbolEntryCur=NULL;  /* Current position in the symbol table */
    struct ExternalSymbolData * externalSymbolDt=NULL;  /* External symbols list */
    struct EntrySymbol * entrySymbolDt=NULL;  /* Entry symbols list */
    struct ExternalSymbolData * curExternalSymbolDt=NULL;  /* Current position in external symbols list */
    struct EntrySymbol * curEntrySymbolDt=NULL;  /* Current position in entry symbols list */

    while(fgets(lineContent, sizeof(lineContent), _inputFile)){  /* Read each line from the file */
        char * decrypted;
        char lineNew[101];
        strcpy(lineNew, lineContent);  /* Copy line for tokenization */
        idxLine++;  /* Increment line index */
        decrypted=strtok(lineNew,"\t ");  /* Tokenize line by tab or space */
        
        if(strchr(decrypted,';')!=NULL) continue;  /* Skip comments */
        else if(strchr(decrypted,':')!=NULL){  /* Handle labels */
            char stateName[25];
            int sz=0;
            int t;
            while(decrypted[sz]!=':'){  /* Find end of label name */
                sz++;
            }
           
            for(t=0;t<sz;t++){
                stateName[t]=decrypted[t];
            }
            stateName[sz]='\0';  /* Null-terminate the label name */
            if(symbolEntryHead==NULL){
                if(validateSymbolInTb(stateName,symbolEntryHead)){  /* Check if label already defined */
                    printf("Error: at contentLine %d already defined above\n",idxLine);
                    errStateLine=1;
                }
                symbolEntryHead=buildSymbolNode (stateName,cntIndex+1);  /* Build first symbol node */
                symbolEntryCur=symbolEntryHead;
            }
            else{
                if(validateSymbolInTb(stateName,symbolEntryHead)){  /* Check if label already defined */
                    printf("Error: at contentLine %d already defined above\n",idxLine);
                    errStateLine=1;
                }
                symbolEntryCur->next=buildSymbolNode (stateName,cntIndex+1);  /* Append new symbol node */
                symbolEntryCur=symbolEntryCur->next;
            }
            decrypted=strtok(NULL,"\t ");
            while(decrypted!=NULL){  /* Process remaining tokens */
                if(decrypted[0]=='r' || decrypted[0]=='*'){  /* Check for register or immediate value */
                    if(decrypted[0]=='*'){
                        if(decrypted[2]>='8' || (decrypted[3]>='0' && decrypted[3]<='9')){
                            printf("Error: at contentLine %d register not identified\n",idxLine);
                            errStateLine=1;
                        }
                    }
                    else{
                        if(decrypted[1]>='8' || (decrypted[2]>='0' && decrypted[2]<='9')){
                            printf("Error: at contentLine %d register not identified\n",idxLine);
                            errStateLine=1;
                        }
                    }
                    decrypted=strtok(NULL,"\t ");
                    if(decrypted==NULL){
                        cntIndex++;
                        break;
                    }
                    if(decrypted[0]=='r' || decrypted[0]=='*'){ 
                        cntIndex++;
                        if(decrypted[0]=='*'){
                            if(decrypted[2]>='8' || (decrypted[3]>='0' && decrypted[3]<='9')){
                                printf("Error: at contentLine %d register not identified\n",idxLine);
                                errStateLine=1;
                            }
                        }
                        else{
                            if(decrypted[1]>='8' || (decrypted[2]>='0' && decrypted[2]<='9')){
                                printf("Error: at contentLine %d register not identified\n",idxLine);
                                errStateLine=1;
                            }
                        }
                    }
                    else{
                        cntIndex+=2;  /* Increment counter for non-register tokens */
                    }
                }
                else if(strstr(decrypted,".string")!=NULL){  /* Handle .string directive */
                    int sz=0;
                    decrypted=strtok(NULL," \t\n");
                    while(decrypted[sz]!='\0' && decrypted[sz]!='\n'){  /* Find length of string */
                        sz++;
                    }
                    cntIndex+=sz-1;  /* Increment counter for string length */
                }
                else if(strstr(decrypted,".data")!=NULL){  /* Handle .data directive */
                    decrypted=strtok(NULL," \t");
                    while(decrypted!=NULL){
                        cntIndex++;  /* Increment counter for each data item */
                        decrypted=strtok(NULL," \t\n");
                    }
                }
                else if(decrypted[0]!='\n') cntIndex++;  /* Increment counter for other tokens */
                decrypted=strtok(NULL,"\t ");
            }
        }

        else if(strcmp(decrypted,".entry")==0){  /* Handle .entry directive */
            int y;
            int sz=0;
            char stateName[25];
            decrypted=strtok(NULL,"\t ");
            while(decrypted[sz]!='\n'){  /* Find end of statement name */
                sz++;
            }
            for(y=0;y<sz;y++){
                stateName[y]=decrypted[y];
            }
            if(decrypted==NULL){
                printf("Error: at contentLine %d instruction_name is wrong\n",idxLine);
                errStateLine=1;
            }
            stateName[sz]='\0';  /* Null-terminate the statement name */
            if(entrySymbolDt==NULL){
                buildNodeEntrySymbol(stateName,&entrySymbolDt);  /* Build new entry node */
                curEntrySymbolDt=entrySymbolDt;
            }
            else{
                buildNodeEntrySymbol(stateName,&(curEntrySymbolDt->next));  /* Append new entry node */
                curEntrySymbolDt=curEntrySymbolDt->next;
            }
            decrypted=strtok(NULL,"\t ");
            if(decrypted!=NULL && decrypted[0]!='\n'){
                printf("Error: at contentLine %d instruction_name is wrong\n",idxLine);
                errStateLine=1;
            }
        }
        else if(strcmp(decrypted,".extern")==0){  /* Handle .extern directive */
            int sz=0;
            char stateName[25];
            int y;
            decrypted=strtok(NULL,"\t ");
            if(decrypted==NULL){
                printf("Error: at contentLine %d instruction_name is wrong\n",idxLine);
                errStateLine=1;
            }
            while(decrypted[sz]!='\n'){  /* Find end of statement name */
                sz++;
            }
            for(y=0;y<sz;y++){
                stateName[y]=decrypted[y];
            }
            stateName[sz]='\0';  /* Null-terminate the statement name */
            if(externalSymbolDt!=NULL){
                buildNodeEnternalSymbol(stateName,&(curExternalSymbolDt->next));  /* Append new extern node */
                curExternalSymbolDt=curExternalSymbolDt->next;
            }
            else{
                buildNodeEnternalSymbol(stateName,&externalSymbolDt);  /* Build new extern node */
                curExternalSymbolDt=externalSymbolDt;
            }
            decrypted=strtok(NULL,"\t ");
            if(decrypted!=NULL && decrypted[0]!='\n'){
                printf("Error: at contentLine %d instruction_name is wrong\n",idxLine);
                errStateLine=1;
            }
        }
        else if(strcmp(decrypted,".extern")==0){  /* Handle .extern directive */
            int sz=0;
            char stateName[25];
            int y;
            decrypted=strtok(NULL,"\t ");
            if(decrypted==NULL){
                printf("Error: at contentLine %d instruction_name is wrong\n",idxLine);
                errStateLine=1;
            }
            while(decrypted[sz]!='\n'){  /* Find end of statement name */
                sz++;
            }
            for(y=0;y<sz;y++){
                stateName[y]=decrypted[y];
            }
            stateName[sz]='\0';  /* Null-terminate the statement name */
            if(externalSymbolDt!=NULL){
                buildNodeEnternalSymbol(stateName,&(curExternalSymbolDt->next));  /* Append new extern node */
                curExternalSymbolDt=curExternalSymbolDt->next;
            }
            else{
                buildNodeEnternalSymbol(stateName,&externalSymbolDt);  /* Build new extern node */
                curExternalSymbolDt=externalSymbolDt;
            }
            decrypted=strtok(NULL,"\t ");
            if(decrypted!=NULL && decrypted[0]!='\n'){
                printf("Error: at contentLine %d instruction_name is wrong\n",idxLine);
                errStateLine=1;
            }
        }
        else{  /* Handle tokens not starting with labels or directives */
            while(decrypted!=NULL){
                if(decrypted[0]=='r' || decrypted[0]=='*'){  /* Check for register or immediate value */
                    if(decrypted[0]=='*'){
                        if(decrypted[2]>='8' || (decrypted[3]>='0' && decrypted[3]<='9')){
                            printf("Error: at contentLine %d register not identified\n",idxLine);
                            errStateLine=1;
                        }
                    }
                    else{
                        if(decrypted[1]>='8' || (decrypted[2]>='0' && decrypted[2]<='9')){
                            printf("Error: at contentLine %d register not identified\n",idxLine);
                            errStateLine=1;
                        }
                    }
                    decrypted=strtok(NULL,"\t ");
                    if(decrypted==NULL){
                        cntIndex++;
                        break;
                    }
                    if(decrypted[0]=='r' || decrypted[0]=='*'){ 
                        cntIndex++;
                        if(decrypted[0]=='*'){
                            if(decrypted[2]>='8' || (decrypted[3]>='0' && decrypted[3]<='9')){
                                printf("Error: at contentLine %d register not identified\n",idxLine);
                                errStateLine=1;
                            }
                        }
                        else{
                            if(decrypted[1]>='8' || (decrypted[2]>='0' && decrypted[2]<='9')){
                                printf("Error: at contentLine %d register not identified\n",idxLine);
                                errStateLine=1;
                            }
                        }
                    }
                    else{
                        cntIndex+=2;  /* Increment counter for non-register tokens */
                    }
                }
                else if(strstr(decrypted,".string")!=NULL){  /* Handle .string directive */
                    int sz=0;
                    decrypted=strtok(NULL," \t\n");
                    while(decrypted[sz]!='\0'){  /* Find length of string */
                        sz++;
                    }
                    cntIndex+=sz-1;  /* Increment counter for string length */
                }
                else if(strstr(decrypted,".data")!=NULL){  /* Handle .data directive */
                    decrypted=strtok(NULL,"\t ");
                    while(decrypted!=NULL){
                       cntIndex++;  /* Increment counter for each data item */
                       decrypted=strtok(NULL," \t\n");
                    }
                }
                else if(decrypted[0]!='\n') cntIndex++;  /* Increment counter for other tokens */
                decrypted=strtok(NULL,"\t ");
            }
        }
    }
    (*_externalSymbolDt)=externalSymbolDt;  /* Set output pointer for external symbols */
    (*_entrySymbolDt)=entrySymbolDt;  /* Set output pointer for entry symbols */
    rewind(_inputFile);  /* Rewind the file to the beginning */
    return symbolEntryHead;  /* Return the head of the symbol table */
}

void buildNodeEntryTb(char _stateName[10], int _addrRef, struct EntryTbData ** _entryTbNode) {
    int t;
    /* Allocate memory for a new table entry node */
    struct EntryTbData * elementEntry = (struct EntryTbData *)malloc(sizeof(struct EntryTbData));
    /* Copy the statement name into the node */
    for(t = 0; t < 10; t++) {
        elementEntry->stateName[t] = _stateName[t];
    }
    /* Set the memory reference and next pointer */
    elementEntry->addrRef = _addrRef;
    elementEntry->next = NULL;
    /* Set the node to point to the newly created element */
    *_entryTbNode = elementEntry;
}

void buildFirstAssemFile(FILE *_resultFile, char* _fileName, struct MacroDefTb **_macroDefTb, FILE ** _inputFile) {
    char lineContent[500];
    int activeM = 0;
    /* Read each line from the input file */
    while (fgets(lineContent, sizeof(lineContent), _resultFile)) {
        if (activeM != 0) {  
            char *decrypt = strtok(lineContent, " \t\n");
            while (decrypt != NULL) {
                if (strcmp(decrypt, "endmacr") == 0) {
                    activeM = 0; /* End macro processing */
                    break;
                }
                decrypt = strtok(NULL, " \t\n");
            }
        } else {
            char *decrypt;
            int cntState = 0;
            char content[500];
            strcpy(content, lineContent);
            decrypt = strtok(lineContent, " \t\n");
            if(content[0] == '\0' || content[0] == '\n') continue; /* Skip empty lines */
            while (decrypt != NULL && decrypt[0] != '\0' && decrypt[0] != '\n') {
                cntState++;
                if (strcmp(decrypt, "macr") == 0) {
                    activeM = 1; /* Start macro processing */
                    break;
                }
                decrypt = strtok(NULL, " \t\n");
            }

            if (activeM == 0) {
                if (cntState == 1) {
                    char *bufMacro = strtok(content, " \t\n");
                    struct MacroElement *ptrMacroData = searchMacroDef(*_macroDefTb, bufMacro);
                    if (ptrMacroData != NULL) {
                        while (ptrMacroData != NULL) {
                            fprintf((*_inputFile), "%s", ptrMacroData->addr);
                            ptrMacroData = ptrMacroData->next;
                        }
                    }
                } else {  
                    fprintf((*_inputFile), "%s", content);
                }
            }
        }
    }
    rewind(*_inputFile); /* Rewind the output file to the beginning */
}


struct ExternalRefTb * buildExternalNode(char _stateName[10], int _addrRef){
    /* Allocate memory for a new external reference node */
    struct ExternalRefTb * elementExternalRef=(struct ExternalRefTb *)malloc(sizeof(struct ExternalRefTb));
    int t;
    /* Copy statement name into the new node */
    for(t=0;t<10;t++){
        elementExternalRef->stateName[t]=_stateName[t];
    }
    elementExternalRef->addrRef=_addrRef; /* Set memory reference */
    elementExternalRef->next=NULL; /* Initialize next pointer to NULL */
    return elementExternalRef;
}

void buildNodeTb(char _arrayDef[], struct MacroDefTb ** _macroDefTbNode) {
    /* Allocate memory for a new macro definition table node */
    struct MacroDefTb *elementMacro = (struct MacroDefTb *)malloc(sizeof(struct MacroDefTb));
    int t;
    /* Copy the macro name into the node */
    for (t = 0; t < 500; t++) {
        elementMacro->macroName[t] = _arrayDef[t];
    }
    /* Initialize the next pointer and definition pointer */
    elementMacro->nextMacro = NULL;
    elementMacro->defPointer = NULL;
    /* Set the node to point to the newly created element */
    *_macroDefTbNode = elementMacro;
}
