#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "helper.h"

/* Create a new bit code node and link it to the list */
void createBitNode(struct BitElement **_bitNodeHead, struct BitElement **_bitNodeCur, int **_bitCode, int * _addr, char _encoded[], char *_parsed) {
    if ((*_bitNodeHead) == NULL) {
        (**_bitCode)++;
        (*_bitNodeHead) = buildBitNode((*_addr)++, _encoded, _parsed);
        (*_bitNodeCur) = (*_bitNodeHead);
    } else {
        (**_bitCode)++;
        (*_bitNodeCur)->next = buildBitNode((*_addr)++, _encoded, _parsed);
        (*_bitNodeCur) = (*_bitNodeCur)->next;
    }
}

/* Process a register based on the given coupon and next coupon values */
void processRegister(char _coupon[], char _nextCoupon[], int *_index, int _token, struct SymbolEntry **_symbolEntry, struct BitElement **_bitNodeHead, struct BitElement **_bitNodeCur, int **_instruction, int *_addrRef) {
    int codeState;
    char registerArray[3];
    int t = 0;
    char encoded[6];
    int cnt;

    /* Extract register part from coupon */
    if (_coupon[0] == '*') {
        for (t = 0; t < 2; t++) {
            registerArray[t] = _coupon[t + 1];
        }
    } else {
        for (t = 0; t < 2; t++) {
            registerArray[t] = _coupon[t];
        }
    }
    registerArray[2] = '\0';

    /* Determine binary code based on token count and next coupon */
    if (*_index + 2 == _token) {
        if (_nextCoupon[0] == 'r' || _nextCoupon[0] == '*') {
            int sourceReg;
            int destReg;
            if (_coupon[0] == '*') {
                sourceReg = _coupon[2] - '0';
            } else {
                sourceReg = _coupon[1] - '0';
            }
            if (_nextCoupon[0] == '*') {
                destReg = _nextCoupon[2] - '0';
            } else {
                destReg = _nextCoupon[1] - '0';
            }
            sourceReg = sourceReg << 6; /* Shift source register bits */
            destReg = destReg << 3;     /* Shift destination register bits */
            codeState = sourceReg | destReg; /* Combine both registers */
            (*_index) += 1;  /* Move to next token */
        } else {
            int sourceReg;
            if (_coupon[0] == '*') {
                sourceReg = _coupon[2] - '0';
            } else {
                sourceReg = _coupon[1] - '0';
            }
            codeState = (sourceReg << 6); /* Only source register */
        }
    } else {
        int destReg;
        destReg = _coupon[1] - '0';
        codeState = destReg << 3; /* Only destination register */
    }
    codeState = codeState | 4; /* Add a fixed bit */
    encoded[5] = '\0';
    cnt = 4;
    processEncoding(cnt, encoded, codeState); /* Encode binary code */
    createBitNode(_bitNodeHead, _bitNodeCur, _instruction, _addrRef, encoded, registerArray); /* Create bit code node */
}


int validateRegister(char *_register) {
    /* Check if arrRegister is a valid register */
    if (_register[0] == 'r' || _register[0] == '*')
        return 1;
    return 0;
}


int insertConstant(char _symbol[], struct SymbolEntry *_symbolEntry) {
    /* Find and return memory reference for a constant */
    while (_symbolEntry != NULL) {
        if (strcmp(_symbol, _symbolEntry->symbolName) != 0) {
            _symbolEntry = _symbolEntry->next;
            continue;
        }
        return _symbolEntry->addrRef;
    }
    return -1; /* Constant not found */
}


int validateConstant(char *_constant) {
    /* Check if check is a valid constant */
    if (_constant[0] == '#')
        return 1;
    return 0;
}

int validateSymbolInTb(char *_symbol, struct SymbolEntry *_baseFileName) {
    /* Check if parsedWord exists in the symbol table */
    while (_baseFileName != NULL) {
        if (strcmp(_symbol, _baseFileName->symbolName) == 0) {
            return 1;
        }
        _baseFileName = _baseFileName->next;
    }
    return 0; /* Symbol not found */
}

int validateEntrySymbol(char _symbol[10], struct EntrySymbol *_baseFileName) {
    /* Check if _symbol_ is an entry symbol */
    while (_baseFileName != NULL) {
        if (strcmp(_symbol, _baseFileName->stateName) == 0)
            return 1;
        _baseFileName = _baseFileName->next;
    }
    return 0; /* Entry symbol not found */
}

int validateExternalSymbol(char _symbol[10], struct ExternalSymbolData *_baseFileName) {
    /* Check if _symbol_ is an extern symbol */
    while (_baseFileName != NULL) {
        if (strcmp(_baseFileName->stateName, _symbol) == 0)
            return 1;
        _baseFileName = _baseFileName->next;
    }
    return 0; /* Extern symbol not found */
}

int validateAddrType(char *_addr) {
    /* Determine the address type based on content */
    if (strchr(_addr, '*') != NULL)
        return 4; /* Indirect address */
    if (strchr(_addr, '#') != NULL)
        return 1; /* Immediate value */
    if (strchr(_addr, 'r') != NULL)
        return 8; /* Register */
    return 2; /* Direct address */
}

void processSymbol(char _coupon[], struct SymbolEntry **_symbolEntry, struct BitElement **_bitNodeHead, struct BitElement **_bitNodeCur, int **_instruction, int *_addrRef, struct ExternalRefTb **_externalRefTb, struct EntryTbData **_curEntryTbData, struct EntryTbData **_entryTbData, struct ExternalRefTb **_curExternalRefTb, char _symbol[25], struct ExternalSymbolData **_externalSymbolData, struct EntrySymbol **_entrySymbol) {
    
    int cntEntry;
    int codeState;
    char encoded[6];
    int cnt;

    /* Insert symbol and compute binary code */
    cntEntry = insertSymbolToTb(_symbol, *_symbolEntry);
    codeState = (cntEntry << 3) | 2;
    encoded[5] = '\0';
    cnt = 4;

    /* Encode codeState */
    processEncoding(cnt, encoded, codeState);
    
    /* Create bit code node */
    createBitNode(_bitNodeHead, _bitNodeCur, _instruction, _addrRef, encoded, _coupon);

    /* Process external symbol */
    if (validateExternalSymbol(_symbol, *_externalSymbolData)) {
        if (_externalRefTb == NULL) {
            (*_externalRefTb) = buildExternalNode(_symbol, cntEntry);
            (*_curExternalRefTb) = *_externalRefTb;
        } else {
            (*_curExternalRefTb)->next = buildExternalNode(_symbol, cntEntry);
            *_curExternalRefTb = (*_curExternalRefTb)->next;
        }
    }
    /* Process entry symbol */
    else if (validateEntrySymbol(_symbol, *_entrySymbol)) {
        if (*_entryTbData == NULL) {
            buildNodeEntryTb(_symbol, cntEntry, _entryTbData);
            *_curEntryTbData = *_entryTbData;
        } else {
            buildNodeEntryTb(_symbol, cntEntry, &((*_curEntryTbData)->next));
            *_curEntryTbData = (*_curEntryTbData)->next;
        }
    }
}

int validateCommand(char *_command) {
    int t;

    /* Validate command by matching with known cmdInstructions */
    for (t = 0; t < 16; t++) {
        if (strcmp(_command, cmdInstructions[t].commandName) == 0)
            return cmdInstructions[t].number;
    }
    return 0; /* Command not found */
}

void emptyExternalSymbol(struct ExternalSymbolData *_externalSymbol) {
    /* Recursively free external symbol data */
    if (_externalSymbol == NULL)
        return;
    if (_externalSymbol->next != NULL) {
        emptyExternalSymbol(_externalSymbol->next);
    }
    free(_externalSymbol);
}

void emptyEntrySymbol(struct EntrySymbol *_entrySymbol) {
    /* Recursively free entry symbol data */
    if (_entrySymbol == NULL)
        return;
    if (_entrySymbol->next != NULL) {
        emptyEntrySymbol(_entrySymbol->next);
    }
    free(_entrySymbol);
}

void emptyExternalTb(struct ExternalRefTb *_externalSymbolTb) {
    /* Recursively free external symbol table */
    if (_externalSymbolTb == NULL)
        return;
    if (_externalSymbolTb->next != NULL) {
        emptyExternalTb(_externalSymbolTb->next);
    }
    free(_externalSymbolTb);
}

void emptyEntryTb(struct EntryTbData *_entrySymbolTb) {
    /* Recursively free entry symbol table */
    if (_entrySymbolTb == NULL)
        return;
    if (_entrySymbolTb->next != NULL) {
        emptyEntryTb(_entrySymbolTb->next);
    }
    free(_entrySymbolTb);
}


void processConstantSymbol(char _coupon[], struct SymbolEntry **_symbolEntry, struct BitElement **_bitNodeHead, struct BitElement **_bitNodeCur, int **_instruction, int *_addrRef) {

    int codeState;
    char encodeArray[6];
    int cnt;

    /* Process numeric constant */
    if ((_coupon[1] >= 48 && _coupon[1] <= 57) || _coupon[1] == '-') {
        int sz = 0;
        int num = 0;
        int trade;

        /* Calculate length of coupon string */
        while (_coupon[sz] != '\0') {
            sz++;
        }
        trade = 1;

        /* Handle negative numbers */
        if (_coupon[1] == '-') {
            int k;
            k = sz - 1;
            for (k = sz - 1; k > 1; k--) {
                num = num + (_coupon[k] - '0') * trade;
                trade *= 10;
            }
            num = ~num + 1; /* Convert to negative value */
        } else {
            int i;
            for (i = sz - 1; i > 0; i--) {
                num = num + (_coupon[i] - '0') * trade;
                trade *= 10;
            }
        }
        codeState = num;
    }
    /* Process symbolic constant */
    else {
        int sz = 0;
        char symbol[10];
        int i;

        /* Calculate length of coupon string */
        while (_coupon[sz] != '\0') {
            sz++;
        }
        for (i = 1; i <= sz; i++) {
            symbol[i - 1] = _coupon[i];
        }
        symbol[sz] = '\0';
        codeState = insertConstant(symbol, *_symbolEntry);
    }
    codeState = codeState << 3 | 4; /* Update codeState */
    encodeArray[5] = '\0';
    cnt = 4;

    /* Encode codeState */
    processEncoding(cnt, encodeArray, codeState);
    
    /* Create bit code node */
    createBitNode(_bitNodeHead, _bitNodeCur, _instruction, _addrRef, encodeArray, _coupon);
}

